const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors({
  origin: 'http://localhost:3000',
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/movies', require('./routes/movies'));
app.use('/api/reviews', require('./routes/reviews'));
app.use('/api/genres', require('./routes/genres'));
app.use('/api/collections', require('./routes/collections'));
app.use('/api/admin', require('./routes/admin'));

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Бет табылмады / Страница не найдена' });
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Сервер қатесі / Внутренняя ошибка сервера' });
});

app.listen(PORT, () => {
  console.log(`\n🎬 CineMax Server running on port ${PORT}`);
  console.log(`📡 API: http://localhost:${PORT}/api`);
  console.log(`\n📋 Setup steps:`);
  console.log(`   1. Create DB: CREATE DATABASE cinemax_db; (in pgAdmin)`);
  console.log(`   2. Run: backend/config/init.sql in pgAdmin`);
  console.log(`   3. Update .env with your DB password`);
});
