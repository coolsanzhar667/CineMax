-- ============================================
-- CineMax Database Schema
-- Run this in pgAdmin Query Tool
-- ============================================

-- Users table (with is_admin role)
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  avatar VARCHAR(255),
  is_admin BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Genres table
CREATE TABLE IF NOT EXISTS genres (
  id SERIAL PRIMARY KEY,
  name VARCHAR(50) UNIQUE NOT NULL,
  name_kz VARCHAR(50),
  name_ru VARCHAR(50)
);

-- Movies table (with trailer_url)
CREATE TABLE IF NOT EXISTS movies (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  title_kz VARCHAR(255),
  description TEXT,
  poster_url VARCHAR(500),
  backdrop_url VARCHAR(500),
  trailer_url VARCHAR(500),
  release_year INTEGER,
  duration INTEGER,
  rating DECIMAL(3,1) DEFAULT 0,
  type VARCHAR(20) CHECK (type IN ('movie', 'series', 'cartoon')) NOT NULL,
  is_new BOOLEAN DEFAULT FALSE,
  is_featured BOOLEAN DEFAULT FALSE,
  language VARCHAR(10) DEFAULT 'RU',
  views INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Movie-Genre junction table
CREATE TABLE IF NOT EXISTS movie_genres (
  movie_id INTEGER REFERENCES movies(id) ON DELETE CASCADE,
  genre_id INTEGER REFERENCES genres(id) ON DELETE CASCADE,
  PRIMARY KEY (movie_id, genre_id)
);

-- Reviews table
CREATE TABLE IF NOT EXISTS reviews (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  movie_id INTEGER REFERENCES movies(id) ON DELETE CASCADE,
  rating INTEGER CHECK (rating >= 1 AND rating <= 10),
  comment TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, movie_id)
);

-- Watchlist table
CREATE TABLE IF NOT EXISTS watchlist (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  movie_id INTEGER REFERENCES movies(id) ON DELETE CASCADE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, movie_id)
);

-- Collections table
CREATE TABLE IF NOT EXISTS collections (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  cover_url VARCHAR(500),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Collection-Movie junction
CREATE TABLE IF NOT EXISTS collection_movies (
  collection_id INTEGER REFERENCES collections(id) ON DELETE CASCADE,
  movie_id INTEGER REFERENCES movies(id) ON DELETE CASCADE,
  PRIMARY KEY (collection_id, movie_id)
);

-- ============================================
-- IMPORTANT: Clear seed data to prevent duplicates on re-run
-- ============================================
TRUNCATE TABLE collection_movies, movie_genres, reviews, watchlist, collections, movies, genres RESTART IDENTITY CASCADE;

-- ============================================
-- Seed Data - Genres
-- ============================================
INSERT INTO genres (name, name_kz, name_ru) VALUES
('action', 'Боевик', 'Боевик'),
('comedy', 'Комедия', 'Комедия'),
('drama', 'Драма', 'Драма'),
('horror', 'Қорқынышты', 'Ужасы'),
('thriller', 'Триллер', 'Триллер'),
('romance', 'Романтика', 'Романтика'),
('sci-fi', 'Ғылыми фантастика', 'Научная фантастика'),
('animation', 'Анимация', 'Анимация'),
('documentary', 'Деректі', 'Документальный'),
('fantasy', 'Фэнтези', 'Фэнтези'),
('adventure', 'Оқиғалы', 'Приключения'),
('crime', 'Қылмыстық', 'Криминал')
ON CONFLICT (name) DO NOTHING;

-- ============================================
-- Seed Data - Movies (with trailer_url, unique posters)
-- ============================================
INSERT INTO movies (title, title_kz, description, poster_url, backdrop_url, trailer_url, release_year, duration, rating, type, is_new, is_featured, views) VALUES
(
  'Inception', 'Бастама',
  'Сознание — последний рубеж. Дом Кобб — талантливый вор, лучший из лучших в опасном искусстве извлечения информации из снов. Его навык стал бесценным в мире корпоративного шпионажа.',
  'https://image.tmdb.org/t/p/w500/9gk7adHYeDvHkCSEqAvQNLV5Uge.jpg',
  'https://image.tmdb.org/t/p/original/s3TBrRGB1iav7gFOCNx3H31MoES.jpg',
  'https://www.youtube.com/watch?v=YoHD9XEInc0',
  2010, 148, 8.8, 'movie', FALSE, TRUE, 15420
),
(
  'The Dark Knight', 'Қараңғы Рыцарь',
  'Бэтмен поднимает ставки в войне с преступностью. С помощью лейтенанта Джима Гордона и прокурора Харви Дента он намерен избавить Готэм от преступности.',
  'https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg',
  'https://image.tmdb.org/t/p/original/hkBaDkMWbLaf8B1lsWsKX7Ew3Xq.jpg',
  'https://www.youtube.com/watch?v=EXeTwQWrcwY',
  2008, 152, 9.0, 'movie', FALSE, TRUE, 22100
),
(
  'Interstellar', 'Жұлдызаралық',
  'Когда засуха приводит человечество к продовольственному кризису, группа исследователей и учёных отправляется сквозь червоточину в путешествие.',
  'https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg',
  'https://image.tmdb.org/t/p/original/pbrkL804S7KMkEaN616QVEv78xz.jpg',
  'https://www.youtube.com/watch?v=zSWdZVtXT7E',
  2014, 169, 8.6, 'movie', FALSE, TRUE, 18750
),
(
  'Breaking Bad', 'Жаман жол',
  'Учитель химии Уолтер Уайт, узнав о смертельном диагнозе, начинает производство метамфетамина вместе со своим бывшим учеником.',
  'https://image.tmdb.org/t/p/w500/ggFHVNu6YYI5L9pCfOacjizRGt.jpg',
  'https://image.tmdb.org/t/p/original/tsRy63Mu5cu8etL1X7ZLyf7UP1M.jpg',
  'https://www.youtube.com/watch?v=HhesaQXLuRY',
  2008, 47, 9.5, 'series', FALSE, TRUE, 31200
),
(
  'Stranger Things', 'Бөтен нәрселер',
  'Когда мальчик исчезает, его мать, друзья и местный шеф полиции обнаруживают секреты и сверхъестественные силы.',
  'https://image.tmdb.org/t/p/w500/x2LSRK2Cm7MZhjluni1msVJ3wDF.jpg',
  'https://image.tmdb.org/t/p/original/56v2KjBlU4XaOv9rVYEQypROD7P.jpg',
  'https://www.youtube.com/watch?v=b9EkMc79ZSU',
  2016, 50, 8.7, 'series', FALSE, FALSE, 28500
),
(
  'The Lion King', 'Арыстан патша',
  'Молодой лев Симба обожает своего отца, короля Муфасу. Но его злобный дядя Шрам подстраивает гибель Муфасы.',
  'https://image.tmdb.org/t/p/w500/sKCr78MXSLixwmZ8DyJLrpMsd15.jpg',
  'https://image.tmdb.org/t/p/original/wXsQvli6tWqja51pYxXNG1LFIGV.jpg',
  'https://www.youtube.com/watch?v=4sj1MT05lAA',
  1994, 88, 8.5, 'cartoon', FALSE, FALSE, 9800
),
(
  'Spider-Man: Across the Spider-Verse', 'Өрмекші Адам: Өрмекші Ғаламшарлар арқылы',
  'Майлз Моралес возвращается в следующей части нового мультфильма о Человеке-Пауке.',
  'https://image.tmdb.org/t/p/w500/8Vt6mWEReuy4Of61Lnj5Xj704m8.jpg',
  'https://image.tmdb.org/t/p/original/4HodYYKEIsGOdinkGi2Ucz6X9i0.jpg',
  'https://www.youtube.com/watch?v=cqGjhVJWtEg',
  2023, 140, 8.7, 'cartoon', TRUE, FALSE, 12300
),
(
  'Oppenheimer', 'Оппенгеймер',
  'История американского физика Дж. Роберта Оппенгеймера и его роли в разработке атомной бомбы во время Второй мировой войны.',
  'https://image.tmdb.org/t/p/w500/8Gxv8gSFCU0XGDykEGv7zR1n2ua.jpg',
  'https://image.tmdb.org/t/p/original/rLb2cwF3Pazuxaj0sRXQ037tGI1.jpg',
  'https://www.youtube.com/watch?v=uYPbbksJxIg',
  2023, 180, 8.4, 'movie', TRUE, TRUE, 14200
),
(
  'Barbie', 'Барби',
  'Барби переживает экзистенциальный кризис и вместе с Кеном отправляется из Барбиленда в реальный мир.',
  'https://image.tmdb.org/t/p/w500/iuFNMS8vlbpDjBNkNseWIOOuRm0.jpg',
  'https://image.tmdb.org/t/p/original/ctMserH8g2SeOAnCw5gFjdQF8mo.jpg',
  'https://www.youtube.com/watch?v=pBk4NYhWNMM',
  2023, 114, 6.9, 'movie', TRUE, FALSE, 9100
),
(
  'The Witcher', 'Ведьмак',
  'Геральт из Ривии — мутировавший охотник на чудовищ — с трудом находит своё место в мире, где люди злее монстров.',
  'https://image.tmdb.org/t/p/w500/7vjaCdMw15FEbXyLQTVa04URsPm.jpg',
  'https://image.tmdb.org/t/p/original/qAHKzqGkNkXb5rMBKVxmjnuqSgt.jpg',
  'https://www.youtube.com/watch?v=ndl8BcgHsac',
  2019, 60, 8.2, 'series', FALSE, FALSE, 17600
),
(
  'Avatar: The Way of Water', 'Аватар: Су жолы',
  'Джейк Салли и Нейтири создали семью и делают всё возможное, чтобы оставаться вместе. Однако им приходится покинуть родной дом.',
  'https://image.tmdb.org/t/p/w500/t6HIqrRAclMCA60NsSmeqe9RmNV.jpg',
  'https://image.tmdb.org/t/p/original/s16H6tpK2utvwpaszVAHDKKa26J.jpg',
  'https://www.youtube.com/watch?v=d9MyW72ELq0',
  2022, 192, 7.6, 'movie', TRUE, FALSE, 11400
),
(
  'Toy Story', 'Ойыншықтар тарихы',
  'Жизнь игрушек в комнате мальчика Энди перевернулась с ног на голову после появления астронавта Базза Лайтера.',
  'https://image.tmdb.org/t/p/w500/uXDfjJbdP4ijW5hWSBrPl9KaI.jpg',
  'https://image.tmdb.org/t/p/original/dji4Fm0gCDVb9DQQMRvAI8YNnTz.jpg',
  'https://www.youtube.com/watch?v=KYz2wyBy3kc',
  1995, 81, 8.3, 'cartoon', FALSE, FALSE, 7600
),
(
  'Wednesday', 'Сәрсенбі',
  'Уэнздей Аддамс учится в школе Невермор Академии, пытаясь освоить свои психические способности и расследовать серию убийств.',
  'https://image.tmdb.org/t/p/w500/9PFonBhy4cQy7Jz20NpMygczOkv.jpg',
  'https://image.tmdb.org/t/p/original/iHSwvRVsRyxpX7FE7GbviaDvgGZ.jpg',
  'https://www.youtube.com/watch?v=Di310WS8zLk',
  2022, 45, 8.1, 'series', TRUE, FALSE, 25300
),
(
  'John Wick', 'Джон Уик',
  'Когда безжалостные преступники врываются в дом бывшего наёмного убийцы, убивают его щенка и угоняют автомобиль — они не знают, кого разбудили.',
  'https://image.tmdb.org/t/p/w500/fZPSd91yGE9fCcCe6OoQr6E3Bev.jpg',
  'https://image.tmdb.org/t/p/original/umC04Cozevu8nn3ZTIU9rNkgftA.jpg',
  'https://www.youtube.com/watch?v=2AUmvWm5ZDQ',
  2014, 101, 7.4, 'movie', FALSE, FALSE, 13700
),
(
  'Encanto', 'Зачарованная страна',
  'Семья Мадригаль живёт в волшебном доме в горах Колумбии. У каждого члена семьи есть свой магический дар — кроме Мирабель.',
  'https://image.tmdb.org/t/p/w500/4j0PNHkMr5ax3IA8tjtxcmPU3QT.jpg',
  'https://image.tmdb.org/t/p/original/3G1Q5xF40HkUBJXxt2DQgQzKTp5.jpg',
  'https://www.youtube.com/watch?v=S0VGmBbfhsY',
  2021, 99, 7.2, 'cartoon', FALSE, FALSE, 8900
);

-- ============================================
-- Assign genres to movies
-- ============================================
INSERT INTO movie_genres (movie_id, genre_id) SELECT 1, id FROM genres WHERE name IN ('action', 'sci-fi', 'thriller') ON CONFLICT DO NOTHING;
INSERT INTO movie_genres (movie_id, genre_id) SELECT 2, id FROM genres WHERE name IN ('action', 'crime', 'drama') ON CONFLICT DO NOTHING;
INSERT INTO movie_genres (movie_id, genre_id) SELECT 3, id FROM genres WHERE name IN ('sci-fi', 'drama', 'adventure') ON CONFLICT DO NOTHING;
INSERT INTO movie_genres (movie_id, genre_id) SELECT 4, id FROM genres WHERE name IN ('crime', 'drama', 'thriller') ON CONFLICT DO NOTHING;
INSERT INTO movie_genres (movie_id, genre_id) SELECT 5, id FROM genres WHERE name IN ('sci-fi', 'horror', 'drama') ON CONFLICT DO NOTHING;
INSERT INTO movie_genres (movie_id, genre_id) SELECT 6, id FROM genres WHERE name IN ('animation', 'adventure', 'drama') ON CONFLICT DO NOTHING;
INSERT INTO movie_genres (movie_id, genre_id) SELECT 7, id FROM genres WHERE name IN ('animation', 'action', 'adventure') ON CONFLICT DO NOTHING;
INSERT INTO movie_genres (movie_id, genre_id) SELECT 8, id FROM genres WHERE name IN ('drama', 'action') ON CONFLICT DO NOTHING;
INSERT INTO movie_genres (movie_id, genre_id) SELECT 9, id FROM genres WHERE name IN ('comedy', 'romance', 'fantasy') ON CONFLICT DO NOTHING;
INSERT INTO movie_genres (movie_id, genre_id) SELECT 10, id FROM genres WHERE name IN ('fantasy', 'action', 'adventure') ON CONFLICT DO NOTHING;
INSERT INTO movie_genres (movie_id, genre_id) SELECT 11, id FROM genres WHERE name IN ('sci-fi', 'action', 'adventure') ON CONFLICT DO NOTHING;
INSERT INTO movie_genres (movie_id, genre_id) SELECT 12, id FROM genres WHERE name IN ('animation', 'comedy', 'adventure') ON CONFLICT DO NOTHING;
INSERT INTO movie_genres (movie_id, genre_id) SELECT 13, id FROM genres WHERE name IN ('horror', 'comedy', 'drama') ON CONFLICT DO NOTHING;
INSERT INTO movie_genres (movie_id, genre_id) SELECT 14, id FROM genres WHERE name IN ('action', 'thriller', 'crime') ON CONFLICT DO NOTHING;
INSERT INTO movie_genres (movie_id, genre_id) SELECT 15, id FROM genres WHERE name IN ('animation', 'comedy', 'fantasy') ON CONFLICT DO NOTHING;

-- ============================================
-- Seed Collections
-- ============================================
INSERT INTO collections (title, description, cover_url) VALUES
('Кино классика', 'Лучшие фильмы всех времён', 'https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg'),
('Новинки 2023', 'Самые ожидаемые фильмы года', 'https://image.tmdb.org/t/p/w500/8Gxv8gSFCU0XGDykEGv7zR1n2ua.jpg'),
('Для всей семьи', 'Мультфильмы и семейное кино', 'https://image.tmdb.org/t/p/w500/4j0PNHkMr5ax3IA8tjtxcmPU3QT.jpg'),
('Лучшие сериалы', 'Топ сериалы которые нужно смотреть', 'https://image.tmdb.org/t/p/w500/ggFHVNu6YYI5L9pCfOacjizRGt.jpg')
ON CONFLICT DO NOTHING;

INSERT INTO collection_movies (collection_id, movie_id) VALUES
(1, 1), (1, 2), (1, 3), (1, 6),
(2, 8), (2, 9), (2, 11),
(3, 6), (3, 7), (3, 12), (3, 15),
(4, 4), (4, 5), (4, 10), (4, 13)
ON CONFLICT DO NOTHING;

-- ============================================
-- Default admin user (password: admin123)
-- Run separately after bcrypt hash if needed,
-- or create via /api/auth/register then:
-- UPDATE users SET is_admin = TRUE WHERE email = 'admin@cinemax.kz';
-- ============================================
