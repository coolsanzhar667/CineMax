const pool = require('../config/db');

const adminMiddleware = async (req, res, next) => {
  try {
    const result = await pool.query('SELECT is_admin FROM users WHERE id = $1', [req.user.id]);
    if (!result.rows[0] || !result.rows[0].is_admin) {
      return res.status(403).json({ error: 'Рұқсат жоқ / Доступ запрещён — только для администраторов' });
    }
    next();
  } catch (err) {
    res.status(500).json({ error: 'Сервер қатесі' });
  }
};

module.exports = adminMiddleware;
