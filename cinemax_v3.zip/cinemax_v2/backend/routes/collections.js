const express = require('express');
const router = express.Router();
const pool = require('../config/db');

// GET /api/collections
router.get('/', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT c.*, 
        COUNT(cm.movie_id) AS movie_count,
        JSON_AGG(
          JSON_BUILD_OBJECT(
            'id', m.id, 'title', m.title, 'poster_url', m.poster_url,
            'rating', m.rating, 'type', m.type
          )
        ) FILTER (WHERE m.id IS NOT NULL) AS movies
      FROM collections c
      LEFT JOIN collection_movies cm ON c.id = cm.collection_id
      LEFT JOIN movies m ON cm.movie_id = m.id
      GROUP BY c.id
      ORDER BY c.created_at DESC
    `);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Сервер қатесі' });
  }
});

// GET /api/collections/:id
router.get('/:id', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT c.*,
        JSON_AGG(
          JSON_BUILD_OBJECT(
            'id', m.id, 'title', m.title, 'poster_url', m.poster_url,
            'rating', m.rating, 'type', m.type, 'release_year', m.release_year,
            'description', m.description
          )
        ) FILTER (WHERE m.id IS NOT NULL) AS movies
      FROM collections c
      LEFT JOIN collection_movies cm ON c.id = cm.collection_id
      LEFT JOIN movies m ON cm.movie_id = m.id
      WHERE c.id = $1
      GROUP BY c.id
    `, [req.params.id]);
    if (!result.rows[0]) return res.status(404).json({ error: 'Подборка не найдена' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Сервер қатесі' });
  }
});

module.exports = router;
