const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const authMiddleware = require('../middleware/auth');
const adminMiddleware = require('../middleware/admin');

// All admin routes require auth + admin role
router.use(authMiddleware, adminMiddleware);

// GET /api/admin/stats — dashboard stats
router.get('/stats', async (req, res) => {
  try {
    const [movies, users, reviews, views] = await Promise.all([
      pool.query('SELECT COUNT(*) FROM movies'),
      pool.query('SELECT COUNT(*) FROM users'),
      pool.query('SELECT COUNT(*) FROM reviews'),
      pool.query('SELECT COALESCE(SUM(views),0) FROM movies'),
    ]);
    const byType = await pool.query(
      `SELECT type, COUNT(*) as count FROM movies GROUP BY type`
    );
    res.json({
      movies: parseInt(movies.rows[0].count),
      users: parseInt(users.rows[0].count),
      reviews: parseInt(reviews.rows[0].count),
      total_views: parseInt(views.rows[0].coalesce),
      by_type: byType.rows,
    });
  } catch (err) { res.status(500).json({ error: 'Сервер қатесі' }); }
});

// GET /api/admin/users — list all users
router.get('/users', async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT id, username, email, is_admin, created_at FROM users ORDER BY created_at DESC'
    );
    res.json(result.rows);
  } catch (err) { res.status(500).json({ error: 'Сервер қатесі' }); }
});

// PATCH /api/admin/users/:id/toggle-admin — grant/revoke admin
router.patch('/users/:id/toggle-admin', async (req, res) => {
  try {
    const result = await pool.query(
      'UPDATE users SET is_admin = NOT is_admin WHERE id = $1 RETURNING id, username, is_admin',
      [req.params.id]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'Пайдаланушы табылмады' });
    res.json(result.rows[0]);
  } catch (err) { res.status(500).json({ error: 'Сервер қатесі' }); }
});

// DELETE /api/admin/users/:id
router.delete('/users/:id', async (req, res) => {
  if (parseInt(req.params.id) === req.user.id)
    return res.status(400).json({ error: 'Өзіңді жоя алмайсың' });
  try {
    await pool.query('DELETE FROM users WHERE id = $1', [req.params.id]);
    res.json({ message: 'Пайдаланушы жойылды' });
  } catch (err) { res.status(500).json({ error: 'Сервер қатесі' }); }
});

// GET /api/admin/reviews — all reviews
router.get('/reviews', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT r.*, u.username, m.title as movie_title
      FROM reviews r
      JOIN users u ON r.user_id = u.id
      JOIN movies m ON r.movie_id = m.id
      ORDER BY r.created_at DESC
      LIMIT 100
    `);
    res.json(result.rows);
  } catch (err) { res.status(500).json({ error: 'Сервер қатесі' }); }
});

// DELETE /api/admin/reviews/:id
router.delete('/reviews/:id', async (req, res) => {
  try {
    await pool.query('DELETE FROM reviews WHERE id = $1', [req.params.id]);
    res.json({ message: 'Пікір жойылды' });
  } catch (err) { res.status(500).json({ error: 'Сервер қатесі' }); }
});

module.exports = router;
