const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const authMiddleware = require('../middleware/auth');
const adminMiddleware = require('../middleware/admin');

// Helper: get movies with aggregated genres — uses subquery to avoid duplicates
const getMoviesQuery = `
  SELECT
    m.*,
    COALESCE(
      (SELECT JSON_AGG(JSON_BUILD_OBJECT('id', g.id, 'name', g.name, 'name_ru', g.name_ru, 'name_kz', g.name_kz))
       FROM movie_genres mg2
       JOIN genres g ON mg2.genre_id = g.id
       WHERE mg2.movie_id = m.id),
      '[]'
    ) AS genres,
    COALESCE(
      (SELECT ROUND(AVG(r.rating)::numeric, 1) FROM reviews r WHERE r.movie_id = m.id),
      m.rating
    ) AS user_rating,
    COALESCE(
      (SELECT COUNT(*) FROM reviews r WHERE r.movie_id = m.id),
      0
    ) AS review_count
  FROM movies m
`;

// GET /api/movies
router.get('/', async (req, res) => {
  const { type, genre, search, sort, limit = 20, page = 1 } = req.query;
  const offset = (page - 1) * limit;

  try {
    let conditions = [];
    let values = [];
    let idx = 1;

    if (type) { conditions.push(`m.type = $${idx++}`); values.push(type); }
    if (genre) {
      // filter by genre without JOIN duplication
      conditions.push(`EXISTS (
        SELECT 1 FROM movie_genres mg3
        JOIN genres g3 ON mg3.genre_id = g3.id
        WHERE mg3.movie_id = m.id AND g3.name = $${idx++}
      )`);
      values.push(genre);
    }
    if (search) {
      conditions.push(`(LOWER(m.title) LIKE $${idx} OR LOWER(m.description) LIKE $${idx})`);
      values.push(`%${search.toLowerCase()}%`);
      idx++;
    }

    const where = conditions.length > 0 ? 'WHERE ' + conditions.join(' AND ') : '';
    let orderBy = 'm.created_at DESC';
    if (sort === 'rating') orderBy = 'm.rating DESC';
    if (sort === 'views') orderBy = 'm.views DESC';
    if (sort === 'year') orderBy = 'm.release_year DESC';

    const query = `
      ${getMoviesQuery}
      ${where}
      ORDER BY ${orderBy}
      LIMIT $${idx++} OFFSET $${idx++}
    `;
    values.push(parseInt(limit), parseInt(offset));

    const result = await pool.query(query, values);
    res.json(result.rows);
  } catch (err) {
    console.error('Movies fetch error:', err);
    res.status(500).json({ error: 'Сервер қатесі' });
  }
});

// GET /api/movies/featured
router.get('/featured', async (req, res) => {
  try {
    const result = await pool.query(`
      ${getMoviesQuery} WHERE m.is_featured = TRUE ORDER BY m.rating DESC LIMIT 5
    `);
    res.json(result.rows);
  } catch (err) { res.status(500).json({ error: 'Сервер қатесі' }); }
});

// GET /api/movies/new
router.get('/new', async (req, res) => {
  try {
    const result = await pool.query(`
      ${getMoviesQuery} WHERE m.is_new = TRUE ORDER BY m.created_at DESC
    `);
    res.json(result.rows);
  } catch (err) { res.status(500).json({ error: 'Сервер қатесі' }); }
});

// GET /api/movies/:id
router.get('/:id', async (req, res) => {
  try {
    const result = await pool.query(`${getMoviesQuery} WHERE m.id = $1`, [req.params.id]);
    if (!result.rows[0]) return res.status(404).json({ error: 'Фильм табылмады' });
    await pool.query('UPDATE movies SET views = views + 1 WHERE id = $1', [req.params.id]);
    res.json(result.rows[0]);
  } catch (err) { res.status(500).json({ error: 'Сервер қатесі' }); }
});

// ── ADMIN: POST /api/movies (create)
router.post('/', authMiddleware, adminMiddleware, async (req, res) => {
  const { title, title_kz, description, poster_url, backdrop_url, trailer_url,
          release_year, duration, rating, type, is_new, is_featured, genre_ids } = req.body;
  if (!title || !type) return res.status(400).json({ error: 'Атауы мен түрі міндетті' });
  try {
    const result = await pool.query(
      `INSERT INTO movies (title, title_kz, description, poster_url, backdrop_url, trailer_url,
        release_year, duration, rating, type, is_new, is_featured)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,
      [title, title_kz, description, poster_url, backdrop_url, trailer_url,
       release_year, duration, rating || 0, type, is_new || false, is_featured || false]
    );
    const movie = result.rows[0];
    if (genre_ids && genre_ids.length > 0) {
      for (const gid of genre_ids) {
        await pool.query(
          'INSERT INTO movie_genres (movie_id, genre_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
          [movie.id, gid]
        );
      }
    }
    res.status(201).json(movie);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Сервер қатесі' });
  }
});

// ── ADMIN: PUT /api/movies/:id (update)
router.put('/:id', authMiddleware, adminMiddleware, async (req, res) => {
  const { title, title_kz, description, poster_url, backdrop_url, trailer_url,
          release_year, duration, rating, type, is_new, is_featured, genre_ids } = req.body;
  try {
    const result = await pool.query(
      `UPDATE movies SET title=$1, title_kz=$2, description=$3, poster_url=$4,
        backdrop_url=$5, trailer_url=$6, release_year=$7, duration=$8,
        rating=$9, type=$10, is_new=$11, is_featured=$12
       WHERE id=$13 RETURNING *`,
      [title, title_kz, description, poster_url, backdrop_url, trailer_url,
       release_year, duration, rating, type, is_new, is_featured, req.params.id]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'Фильм табылмады' });
    if (genre_ids) {
      await pool.query('DELETE FROM movie_genres WHERE movie_id = $1', [req.params.id]);
      for (const gid of genre_ids) {
        await pool.query(
          'INSERT INTO movie_genres (movie_id, genre_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
          [req.params.id, gid]
        );
      }
    }
    res.json(result.rows[0]);
  } catch (err) { res.status(500).json({ error: 'Сервер қатесі' }); }
});

// ── ADMIN: DELETE /api/movies/:id
router.delete('/:id', authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const result = await pool.query('DELETE FROM movies WHERE id = $1 RETURNING id', [req.params.id]);
    if (!result.rows[0]) return res.status(404).json({ error: 'Фильм табылмады' });
    res.json({ message: 'Фильм жойылды' });
  } catch (err) { res.status(500).json({ error: 'Сервер қатесі' }); }
});

module.exports = router;
