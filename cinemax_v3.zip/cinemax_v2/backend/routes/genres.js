const express = require('express');
const router = express.Router();
const pool = require('../config/db');

// GET /api/genres
router.get('/', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM genres ORDER BY name_ru');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Сервер қатесі' });
  }
});

module.exports = router;
