const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const authMiddleware = require('../middleware/auth');

// GET /api/reviews/movie/:movieId
router.get('/movie/:movieId', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT r.*, u.username, u.avatar
      FROM reviews r
      JOIN users u ON r.user_id = u.id
      WHERE r.movie_id = $1
      ORDER BY r.created_at DESC
    `, [req.params.movieId]);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Сервер қатесі' });
  }
});

// POST /api/reviews - add review (auth required)
router.post('/', authMiddleware, async (req, res) => {
  const { movie_id, rating, comment } = req.body;

  if (!movie_id || !rating || !comment) {
    return res.status(400).json({ error: 'Барлық өрістерді толтырыңыз' });
  }

  if (rating < 1 || rating > 10) {
    return res.status(400).json({ error: 'Баға 1-ден 10-ға дейін болуы керек' });
  }

  try {
    const existing = await pool.query(
      'SELECT id FROM reviews WHERE user_id = $1 AND movie_id = $2',
      [req.user.id, movie_id]
    );

    if (existing.rows.length > 0) {
      // Update existing review
      const result = await pool.query(
        'UPDATE reviews SET rating = $1, comment = $2 WHERE user_id = $3 AND movie_id = $4 RETURNING *',
        [rating, comment, req.user.id, movie_id]
      );
      return res.json(result.rows[0]);
    }

    const result = await pool.query(
      'INSERT INTO reviews (user_id, movie_id, rating, comment) VALUES ($1, $2, $3, $4) RETURNING *',
      [req.user.id, movie_id, rating, comment]
    );

    // Update movie rating
    await pool.query(`
      UPDATE movies SET rating = (
        SELECT ROUND(AVG(rating)::numeric, 1) FROM reviews WHERE movie_id = $1
      ) WHERE id = $1
    `, [movie_id]);

    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error('Review error:', err);
    res.status(500).json({ error: 'Сервер қатесі' });
  }
});

// DELETE /api/reviews/:id
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    const result = await pool.query(
      'DELETE FROM reviews WHERE id = $1 AND user_id = $2 RETURNING *',
      [req.params.id, req.user.id]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'Пікір табылмады' });
    res.json({ message: 'Пікір жойылды' });
  } catch (err) {
    res.status(500).json({ error: 'Сервер қатесі' });
  }
});

module.exports = router;
