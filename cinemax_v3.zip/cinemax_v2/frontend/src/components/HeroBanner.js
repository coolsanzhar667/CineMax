import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './HeroBanner.css';

function getYouTubeId(url) {
  if (!url) return null;
  const r = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/);
  return r ? r[1] : null;
}

const HeroBanner = ({ movies }) => {
  const [current, setCurrent] = useState(0);
  const [showTrailer, setShowTrailer] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (!movies?.length) return;
    const timer = setInterval(() => {
      setCurrent(prev => (prev + 1) % movies.length);
      setShowTrailer(false);
    }, 6000);
    return () => clearInterval(timer);
  }, [movies]);

  if (!movies?.length) return <div className="hero hero--loading skeleton" />;

  const movie = movies[current];
  const genres = Array.isArray(movie.genres)
    ? movie.genres.slice(0, 3).map(g => g.name_ru || g.name).join(' · ')
    : '';
  const youtubeId = getYouTubeId(movie.trailer_url);

  return (
    <div className="hero">
      <div className="hero__bg">
        <img
          key={movie.id}
          src={movie.backdrop_url || movie.poster_url}
          alt={movie.title}
          className="hero__bg-img"
          onError={e => { e.target.src = movie.poster_url; }}
        />
        <div className="hero__gradient" />
      </div>

      <div className="hero__content container">
        <div className="hero__badges">
          {movie.is_new && <span className="badge badge-new">Жаңа / New</span>}
          {movie.is_featured && <span className="hero__featured-badge">⭐ Топтаулы / Рекомендуем</span>}
        </div>

        <h1 className="hero__title">{movie.title}</h1>

        <div className="hero__meta">
          <span className="hero__rating">
            <svg viewBox="0 0 24 24" fill="#f5c518" width="18" height="18">
              <polygon points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26"/>
            </svg>
            {Number(movie.rating).toFixed(1)}
          </span>
          {movie.release_year && <span>{movie.release_year}</span>}
          {movie.duration && <span>{movie.duration} мин</span>}
          {genres && <span className="hero__genres">{genres}</span>}
        </div>

        <p className="hero__description">
          {movie.description?.length > 180 ? movie.description.slice(0, 180) + '...' : movie.description}
        </p>

        <div className="hero__actions">
          {youtubeId ? (
            <button className="hero__btn hero__btn--play" onClick={() => setShowTrailer(true)}>
              <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20">
                <polygon points="5,3 19,12 5,21"/>
              </svg>
              Трейлер / Смотреть
            </button>
          ) : (
            <button className="hero__btn hero__btn--play" onClick={() => navigate('/movie/' + movie.id)}>
              <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20">
                <polygon points="5,3 19,12 5,21"/>
              </svg>
              Қарау / Смотреть
            </button>
          )}
          <button className="hero__btn hero__btn--info" onClick={() => navigate('/movie/' + movie.id)}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="20" height="20">
              <circle cx="12" cy="12" r="10"/>
              <line x1="12" y1="8" x2="12" y2="12"/>
              <line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
            Толығырақ / Подробнее
          </button>
        </div>
      </div>

      {movies.length > 1 && (
        <div className="hero__dots">
          {movies.map((_, i) => (
            <button key={i}
              className={"hero__dot" + (i === current ? " hero__dot--active" : "")}
              onClick={() => { setCurrent(i); setShowTrailer(false); }}
            />
          ))}
        </div>
      )}

      {/* YouTube trailer modal */}
      {showTrailer && youtubeId && (
        <div className="trailer-modal" onClick={() => setShowTrailer(false)}>
          <div className="trailer-modal__content" onClick={e => e.stopPropagation()}>
            <button className="trailer-modal__close" onClick={() => setShowTrailer(false)}>✕</button>
            <div className="trailer-modal__video">
              <iframe
                src={"https://www.youtube.com/embed/" + youtubeId + "?autoplay=1&rel=0"}
                title={movie.title + " трейлер"}
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
            <div className="trailer-modal__title">{movie.title} — Трейлер</div>
          </div>
        </div>
      )}
    </div>
  );
};

export default HeroBanner;
