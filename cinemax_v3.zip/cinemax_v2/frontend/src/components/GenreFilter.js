import React from 'react';
import './GenreFilter.css';

const GenreFilter = ({ genres, selected, onSelect }) => {
  return (
    <div className="genre-filter">
      <button
        className={`genre-filter__btn ${!selected ? 'genre-filter__btn--active' : ''}`}
        onClick={() => onSelect(null)}
      >
        Барлығы / Все
      </button>
      {genres.map(genre => (
        <button
          key={genre.id}
          className={`genre-filter__btn ${selected === genre.name ? 'genre-filter__btn--active' : ''}`}
          onClick={() => onSelect(genre.name)}
        >
          {genre.name_ru || genre.name}
        </button>
      ))}
    </div>
  );
};

export default GenreFilter;
