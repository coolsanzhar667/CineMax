import React from 'react';
import MovieCard from './MovieCard';
import './MovieGrid.css';

const MovieGrid = ({ movies, loading }) => {
  if (loading) {
    return (
      <div className="movie-grid">
        {Array.from({ length: 12 }).map((_, i) => (
          <div key={i} className="movie-grid__skeleton skeleton" />
        ))}
      </div>
    );
  }

  if (!movies?.length) {
    return (
      <div className="movie-grid__empty">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <rect x="2" y="2" width="20" height="20" rx="2" />
          <path d="M8 10h8M8 14h5" />
        </svg>
        <p>Фильм табылмады / Фильмы не найдены</p>
        <small>Басқа жанрды таңдаңыз / Попробуйте другой жанр</small>
      </div>
    );
  }

  return (
    <div className="movie-grid">
      {movies.map(movie => (
        <div key={movie.id} className="movie-grid__item">
          <MovieCard movie={movie} />
        </div>
      ))}
    </div>
  );
};

export default MovieGrid;
