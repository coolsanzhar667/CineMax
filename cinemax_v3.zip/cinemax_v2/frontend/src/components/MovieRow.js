import React from 'react';
import MovieCard from './MovieCard';
import './MovieRow.css';

const MovieRow = ({ title, movies, loading }) => {
  if (!loading && (!movies || movies.length === 0)) return null;

  return (
    <div className="movie-row">
      <h2 className="section-title">{title}</h2>
      <div className="movie-row__scroll">
        {loading
          ? Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="movie-row__skeleton skeleton" />
            ))
          : movies.map(movie => (
              <MovieCard key={movie.id} movie={movie} />
            ))
        }
      </div>
    </div>
  );
};

export default MovieRow;
