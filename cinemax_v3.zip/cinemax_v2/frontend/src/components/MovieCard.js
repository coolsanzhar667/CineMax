import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './MovieCard.css';

const typeLabels = {
  movie: 'Фильм',
  series: 'Сериал',
  cartoon: 'Мультфильм',
};

const MovieCard = ({ movie }) => {
  const navigate = useNavigate();
  const [imgError, setImgError] = useState(false);

  const handleClick = () => navigate(`/movie/${movie.id}`);

  const genres = Array.isArray(movie.genres)
    ? movie.genres.slice(0, 2).map(g => g.name_ru || g.name).join(' · ')
    : '';

  return (
    <div className="movie-card" onClick={handleClick}>
      <div className="movie-card__poster">
        {!imgError && movie.poster_url ? (
          <img
            src={movie.poster_url}
            alt={movie.title}
            onError={() => setImgError(true)}
            loading="lazy"
          />
        ) : (
          <div className="movie-card__no-poster">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1">
              <rect x="2" y="2" width="20" height="20" rx="2" />
              <circle cx="12" cy="10" r="3" />
              <path d="M7 21v-1a5 5 0 0 1 10 0v1" />
            </svg>
            <span>{movie.title}</span>
          </div>
        )}

        {/* Hover overlay */}
        <div className="movie-card__overlay">
          <button className="movie-card__play">
            <svg viewBox="0 0 24 24" fill="currentColor">
              <polygon points="5,3 19,12 5,21" />
            </svg>
          </button>
          <div className="movie-card__overlay-info">
            <div className="movie-card__rating">
              <svg viewBox="0 0 24 24" fill="#f5c518" width="14" height="14">
                <polygon points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26" />
              </svg>
              {Number(movie.rating).toFixed(1)}
            </div>
            {genres && <div className="movie-card__genres">{genres}</div>}
          </div>
        </div>

        {/* Badges */}
        <div className="movie-card__badges">
          {movie.is_new && <span className="badge badge-new">New</span>}
          <span className={`badge badge-${movie.type}`}>{typeLabels[movie.type]}</span>
        </div>
      </div>

      <div className="movie-card__info">
        <h3 className="movie-card__title">{movie.title}</h3>
        <div className="movie-card__meta">
          <span>{movie.release_year}</span>
          {movie.duration && <span>{movie.duration} мин</span>}
        </div>
      </div>
    </div>
  );
};

export default MovieCard;
