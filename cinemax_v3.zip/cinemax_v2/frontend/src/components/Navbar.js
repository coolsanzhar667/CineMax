import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import './Navbar.css';

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const searchRef = useRef(null);
  const dropdownRef = useRef(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    if (searchOpen && searchRef.current) searchRef.current.focus();
  }, [searchOpen]);

  useEffect(() => {
    setMobileOpen(false);
    setDropdownOpen(false);
    setSearchOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate('/movies?search=' + encodeURIComponent(searchQuery.trim()));
      setSearchOpen(false); setSearchQuery('');
    }
  };

  const navLinks = [
    { to: '/', label: 'Басты бет', labelRu: 'Главная' },
    { to: '/movies', label: 'Фильмдер', labelRu: 'Фильмы' },
    { to: '/series', label: 'Сериалдар', labelRu: 'Сериалы' },
    { to: '/cartoons', label: 'Мультфильмдер', labelRu: 'Мультфильмы' },
    { to: '/new', label: 'Жаңалықтар', labelRu: 'Новинки' },
    { to: '/collections', label: 'Топтамалар', labelRu: 'Подборки' },
  ];

  return (
    <nav className={"navbar" + (scrolled ? " navbar--scrolled" : "")}>
      <div className="navbar__inner">
        <Link to="/" className="navbar__logo">CINE<span>MAX</span></Link>

        <ul className="navbar__links">
          {navLinks.map(({ to, label, labelRu }) => (
            <li key={to}>
              <Link to={to} className={"navbar__link" + (location.pathname === to ? " navbar__link--active" : "")}>
                <span className="nav-kz">{label}</span>
                <span className="nav-ru">{labelRu}</span>
              </Link>
            </li>
          ))}
        </ul>

        <div className="navbar__right">
          {/* Search */}
          <div className={"navbar__search" + (searchOpen ? " navbar__search--open" : "")}>
            <form onSubmit={handleSearch}>
              <input ref={searchRef} type="text" placeholder="Іздеу... / Поиск..."
                value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
            </form>
            <button className="navbar__icon-btn" onClick={() => setSearchOpen(!searchOpen)}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
              </svg>
            </button>
          </div>

          {/* User dropdown — completely separate from mobile menu */}
          {user ? (
            <div className="navbar__user" ref={dropdownRef}>
              <button className="navbar__user-btn" onClick={() => setDropdownOpen(!dropdownOpen)}>
                <div className={"navbar__avatar" + (user.is_admin ? " navbar__avatar--admin" : "")}>
                  {user.is_admin ? '★' : user.username?.[0]?.toUpperCase()}
                </div>
                <span className="navbar__username">
                  {user.username}
                  {user.is_admin && <span className="navbar__admin-badge">ADMIN</span>}
                </span>
                <svg className={"navbar__chevron" + (dropdownOpen ? " open" : "")}
                  viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <polyline points="6 9 12 15 18 9"/>
                </svg>
              </button>

              {dropdownOpen && (
                <div className="navbar__dropdown">
                  <div className="navbar__dropdown-header">
                    <strong>{user.username}</strong>
                    <small>{user.email}</small>
                    {user.is_admin && <span className="dropdown-admin-label">Администратор</span>}
                  </div>
                  {user.is_admin && (
                    <Link to="/admin" className="navbar__dropdown-link navbar__dropdown-link--admin"
                      onClick={() => setDropdownOpen(false)}>
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="16" height="16">
                        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                      </svg>
                      Админ панель
                    </Link>
                  )}
                  <button onClick={() => { logout(); setDropdownOpen(false); }} className="navbar__logout">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
                      <polyline points="16 17 21 12 16 7"/>
                      <line x1="21" y1="12" x2="9" y2="12"/>
                    </svg>
                    Шығу / Выйти
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="navbar__auth-btns">
              <Link to="/login" className="btn-ghost">Кіру</Link>
              <Link to="/register" className="btn-accent">Тіркелу</Link>
            </div>
          )}

          {/* Burger — only for mobile nav links */}
          <button className="navbar__burger" onClick={() => setMobileOpen(!mobileOpen)}>
            <span/><span/><span/>
          </button>
        </div>
      </div>

      {/* Mobile menu — links only, no user dropdown here */}
      {mobileOpen && (
        <div className="navbar__mobile-menu">
          {navLinks.map(({ to, labelRu }) => (
            <Link key={to} to={to} className="navbar__mobile-link">{labelRu}</Link>
          ))}
          {user?.is_admin && (
            <Link to="/admin" className="navbar__mobile-link navbar__mobile-link--admin">★ Админ панель</Link>
          )}
          {user ? (
            <button className="navbar__mobile-logout" onClick={() => { logout(); setMobileOpen(false); }}>
              Шығу / Выйти
            </button>
          ) : (
            <div className="navbar__mobile-auth">
              <Link to="/login" className="btn-ghost">Войти</Link>
              <Link to="/register" className="btn-accent">Регистрация</Link>
            </div>
          )}
        </div>
      )}
    </nav>
  );
};

export default Navbar;
