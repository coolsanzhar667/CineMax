import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';
import './AdminPanel.css';

const EMPTY_MOVIE = {
  title: '', title_kz: '', description: '',
  poster_url: '', backdrop_url: '', trailer_url: '',
  release_year: new Date().getFullYear(),
  duration: '', rating: '', type: 'movie',
  is_new: false, is_featured: false, genre_ids: []
};

const AdminPanel = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState('dashboard');

  // Dashboard
  const [stats, setStats] = useState(null);

  // Movies
  const [movies, setMovies] = useState([]);
  const [genres, setGenres] = useState([]);
  const [movieForm, setMovieForm] = useState(EMPTY_MOVIE);
  const [editingMovie, setEditingMovie] = useState(null);
  const [showMovieForm, setShowMovieForm] = useState(false);
  const [movieSearch, setMovieSearch] = useState('');
  const [movieMsg, setMovieMsg] = useState('');
  const [movieErr, setMovieErr] = useState('');

  // Users
  const [users, setUsers] = useState([]);

  // Reviews
  const [reviews, setReviews] = useState([]);

  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user || !user.is_admin) { navigate('/'); return; }
    loadStats();
    api.get('/genres').then(r => setGenres(r.data));
  }, [user, navigate]);

  useEffect(() => {
    if (tab === 'dashboard') loadStats();
    if (tab === 'movies') loadMovies();
    if (tab === 'users') loadUsers();
    if (tab === 'reviews') loadReviews();
  }, [tab]);

  const loadStats = async () => {
    try {
      const r = await api.get('/admin/stats');
      setStats(r.data);
    } catch (e) { console.error(e); }
  };

  const loadMovies = async () => {
    setLoading(true);
    try {
      const r = await api.get('/movies?limit=100');
      setMovies(r.data);
    } catch (e) { console.error(e); } finally { setLoading(false); }
  };

  const loadUsers = async () => {
    setLoading(true);
    try {
      const r = await api.get('/admin/users');
      setUsers(r.data);
    } catch (e) { console.error(e); } finally { setLoading(false); }
  };

  const loadReviews = async () => {
    setLoading(true);
    try {
      const r = await api.get('/admin/reviews');
      setReviews(r.data);
    } catch (e) { console.error(e); } finally { setLoading(false); }
  };

  // ── Movie form helpers
  const openAddMovie = () => {
    setEditingMovie(null);
    setMovieForm(EMPTY_MOVIE);
    setMovieMsg(''); setMovieErr('');
    setShowMovieForm(true);
  };

  const openEditMovie = (movie) => {
    setEditingMovie(movie.id);
    setMovieForm({
      title: movie.title || '',
      title_kz: movie.title_kz || '',
      description: movie.description || '',
      poster_url: movie.poster_url || '',
      backdrop_url: movie.backdrop_url || '',
      trailer_url: movie.trailer_url || '',
      release_year: movie.release_year || '',
      duration: movie.duration || '',
      rating: movie.rating || '',
      type: movie.type || 'movie',
      is_new: movie.is_new || false,
      is_featured: movie.is_featured || false,
      genre_ids: Array.isArray(movie.genres) ? movie.genres.map(g => g.id) : []
    });
    setMovieMsg(''); setMovieErr('');
    setShowMovieForm(true);
    window.scrollTo(0, 0);
  };

  const handleMovieFormChange = (e) => {
    const { name, value, type, checked } = e.target;
    setMovieForm(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
  };

  const handleGenreToggle = (gid) => {
    setMovieForm(prev => ({
      ...prev,
      genre_ids: prev.genre_ids.includes(gid)
        ? prev.genre_ids.filter(id => id !== gid)
        : [...prev.genre_ids, gid]
    }));
  };

  const handleMovieSubmit = async (e) => {
    e.preventDefault();
    setMovieErr(''); setMovieMsg('');
    if (!movieForm.title) { setMovieErr('Атауын енгізіңіз'); return; }
    try {
      if (editingMovie) {
        await api.put(`/movies/${editingMovie}`, movieForm);
        setMovieMsg('✅ Фильм жаңартылды!');
      } else {
        await api.post('/movies', movieForm);
        setMovieMsg('✅ Фильм қосылды!');
      }
      loadMovies();
      setTimeout(() => { setShowMovieForm(false); setMovieMsg(''); }, 1500);
    } catch (err) {
      setMovieErr(err.response?.data?.error || 'Қате болды');
    }
  };

  const handleDeleteMovie = async (id, title) => {
    if (!window.confirm(`"${title}" фильмін жойғыңыз келе ме?`)) return;
    try {
      await api.delete(`/movies/${id}`);
      setMovies(prev => prev.filter(m => m.id !== id));
    } catch (err) { alert(err.response?.data?.error || 'Жою мүмкін болмады'); }
  };

  const handleToggleAdmin = async (id) => {
    try {
      const r = await api.patch(`/admin/users/${id}/toggle-admin`);
      setUsers(prev => prev.map(u => u.id === id ? { ...u, is_admin: r.data.is_admin } : u));
    } catch (err) { alert(err.response?.data?.error || 'Қате болды'); }
  };

  const handleDeleteUser = async (id, username) => {
    if (!window.confirm(`"${username}" пайдаланушысын жойғыңыз келе ме?`)) return;
    try {
      await api.delete(`/admin/users/${id}`);
      setUsers(prev => prev.filter(u => u.id !== id));
    } catch (err) { alert(err.response?.data?.error || 'Жою мүмкін болмады'); }
  };

  const handleDeleteReview = async (id) => {
    if (!window.confirm('Пікірді жойғыңыз келе ме?')) return;
    try {
      await api.delete(`/admin/reviews/${id}`);
      setReviews(prev => prev.filter(r => r.id !== id));
    } catch (err) { alert('Жою мүмкін болмады'); }
  };

  const filteredMovies = movies.filter(m =>
    m.title.toLowerCase().includes(movieSearch.toLowerCase())
  );

  if (!user?.is_admin) return null;

  return (
    <div className="admin page-wrapper">
      <div className="admin__sidebar">
        <div className="admin__logo">
          <span>★</span> ADMIN
        </div>
        <nav className="admin__nav">
          {[
            { key: 'dashboard', icon: '📊', label: 'Басқару тақтасы' },
            { key: 'movies', icon: '🎬', label: 'Фильмдер' },
            { key: 'users', icon: '👥', label: 'Пайдаланушылар' },
            { key: 'reviews', icon: '💬', label: 'Пікірлер' },
          ].map(({ key, icon, label }) => (
            <button
              key={key}
              className={`admin__nav-item ${tab === key ? 'admin__nav-item--active' : ''}`}
              onClick={() => setTab(key)}
            >
              <span>{icon}</span> {label}
            </button>
          ))}
        </nav>
        <button className="admin__back-btn" onClick={() => navigate('/')}>
          ← Сайтқа оралу
        </button>
      </div>

      <div className="admin__content">

        {/* ── DASHBOARD ── */}
        {tab === 'dashboard' && (
          <div className="admin__section">
            <h1 className="admin__title">Басқару тақтасы</h1>
            {stats ? (
              <>
                <div className="admin__stats-grid">
                  <div className="admin__stat-card admin__stat-card--red">
                    <div className="admin__stat-icon">🎬</div>
                    <div className="admin__stat-value">{stats.movies}</div>
                    <div className="admin__stat-label">Барлық фильмдер</div>
                  </div>
                  <div className="admin__stat-card admin__stat-card--blue">
                    <div className="admin__stat-icon">👥</div>
                    <div className="admin__stat-value">{stats.users}</div>
                    <div className="admin__stat-label">Пайдаланушылар</div>
                  </div>
                  <div className="admin__stat-card admin__stat-card--green">
                    <div className="admin__stat-icon">💬</div>
                    <div className="admin__stat-value">{stats.reviews}</div>
                    <div className="admin__stat-label">Пікірлер</div>
                  </div>
                  <div className="admin__stat-card admin__stat-card--gold">
                    <div className="admin__stat-icon">👁️</div>
                    <div className="admin__stat-value">{stats.total_views?.toLocaleString()}</div>
                    <div className="admin__stat-label">Жалпы қаралымдар</div>
                  </div>
                </div>
                <h2 className="admin__subtitle">Түрлер бойынша</h2>
                <div className="admin__type-breakdown">
                  {stats.by_type?.map(({ type, count }) => (
                    <div key={type} className="admin__type-item">
                      <span>{type === 'movie' ? '🎥 Фильмдер' : type === 'series' ? '📺 Сериалдар' : '🎠 Мультфильмдер'}</span>
                      <strong>{count}</strong>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <div className="admin__loading">Жүктелуде...</div>
            )}
          </div>
        )}

        {/* ── MOVIES ── */}
        {tab === 'movies' && (
          <div className="admin__section">
            <div className="admin__section-header">
              <h1 className="admin__title">Фильмдерді басқару</h1>
              <button className="admin__add-btn" onClick={openAddMovie}>+ Фильм қосу</button>
            </div>

            {/* Movie Form */}
            {showMovieForm && (
              <div className="admin__form-card">
                <div className="admin__form-header">
                  <h2>{editingMovie ? '✏️ Фильмді өңдеу' : '➕ Жаңа фильм қосу'}</h2>
                  <button className="admin__form-close" onClick={() => setShowMovieForm(false)}>✕</button>
                </div>
                {movieErr && <div className="error-msg">{movieErr}</div>}
                {movieMsg && <div className="success-msg">{movieMsg}</div>}
                <form onSubmit={handleMovieSubmit} className="admin__movie-form">
                  <div className="admin__form-row">
                    <div className="admin__form-field">
                      <label>Атауы (орысша) *</label>
                      <input name="title" value={movieForm.title} onChange={handleMovieFormChange} placeholder="Inception" required />
                    </div>
                    <div className="admin__form-field">
                      <label>Атауы (қазақша)</label>
                      <input name="title_kz" value={movieForm.title_kz} onChange={handleMovieFormChange} placeholder="Бастама" />
                    </div>
                  </div>
                  <div className="admin__form-field">
                    <label>Сипаттама</label>
                    <textarea name="description" value={movieForm.description} onChange={handleMovieFormChange} rows={3} placeholder="Фильм туралы..." />
                  </div>
                  <div className="admin__form-row">
                    <div className="admin__form-field">
                      <label>Постер URL</label>
                      <input name="poster_url" value={movieForm.poster_url} onChange={handleMovieFormChange} placeholder="https://..." />
                    </div>
                    <div className="admin__form-field">
                      <label>Фон сурет URL</label>
                      <input name="backdrop_url" value={movieForm.backdrop_url} onChange={handleMovieFormChange} placeholder="https://..." />
                    </div>
                  </div>
                  <div className="admin__form-field">
                    <label>🎬 Трейлер YouTube URL</label>
                    <input name="trailer_url" value={movieForm.trailer_url} onChange={handleMovieFormChange} placeholder="https://www.youtube.com/watch?v=..." />
                  </div>
                  <div className="admin__form-row">
                    <div className="admin__form-field">
                      <label>Түрі *</label>
                      <select name="type" value={movieForm.type} onChange={handleMovieFormChange}>
                        <option value="movie">Фильм</option>
                        <option value="series">Сериал</option>
                        <option value="cartoon">Мультфильм</option>
                      </select>
                    </div>
                    <div className="admin__form-field">
                      <label>Шыққан жыл</label>
                      <input type="number" name="release_year" value={movieForm.release_year} onChange={handleMovieFormChange} min="1900" max="2030" />
                    </div>
                    <div className="admin__form-field">
                      <label>Ұзақтығы (мин)</label>
                      <input type="number" name="duration" value={movieForm.duration} onChange={handleMovieFormChange} min="1" />
                    </div>
                    <div className="admin__form-field">
                      <label>Рейтинг (0-10)</label>
                      <input type="number" name="rating" value={movieForm.rating} onChange={handleMovieFormChange} min="0" max="10" step="0.1" />
                    </div>
                  </div>
                  <div className="admin__form-row admin__form-row--checks">
                    <label className="admin__checkbox">
                      <input type="checkbox" name="is_new" checked={movieForm.is_new} onChange={handleMovieFormChange} />
                      Жаңа (New)
                    </label>
                    <label className="admin__checkbox">
                      <input type="checkbox" name="is_featured" checked={movieForm.is_featured} onChange={handleMovieFormChange} />
                      Ұсынылған (Featured)
                    </label>
                  </div>
                  <div className="admin__form-field">
                    <label>Жанрлар</label>
                    <div className="admin__genre-grid">
                      {genres.map(g => (
                        <label key={g.id} className={`admin__genre-tag ${movieForm.genre_ids.includes(g.id) ? 'admin__genre-tag--selected' : ''}`}>
                          <input type="checkbox" checked={movieForm.genre_ids.includes(g.id)} onChange={() => handleGenreToggle(g.id)} style={{ display: 'none' }} />
                          {g.name_ru || g.name}
                        </label>
                      ))}
                    </div>
                  </div>
                  <div className="admin__form-actions">
                    <button type="submit" className="admin__submit-btn">
                      {editingMovie ? 'Сақтау' : 'Қосу'}
                    </button>
                    <button type="button" className="admin__cancel-btn" onClick={() => setShowMovieForm(false)}>
                      Болдырмау
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* Movies search + table */}
            <div className="admin__search-bar">
              <input
                type="text"
                placeholder="Фильм іздеу..."
                value={movieSearch}
                onChange={e => setMovieSearch(e.target.value)}
              />
              <span className="admin__count">{filteredMovies.length} фильм</span>
            </div>

            {loading ? (
              <div className="admin__loading">Жүктелуде...</div>
            ) : (
              <div className="admin__table-wrap">
                <table className="admin__table">
                  <thead>
                    <tr>
                      <th>Постер</th>
                      <th>Атауы</th>
                      <th>Түрі</th>
                      <th>Жыл</th>
                      <th>Рейтинг</th>
                      <th>Трейлер</th>
                      <th>Жаңа</th>
                      <th>Әрекет</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredMovies.map(movie => (
                      <tr key={movie.id}>
                        <td>
                          <img
                            src={movie.poster_url}
                            alt={movie.title}
                            className="admin__poster-thumb"
                            onError={e => { e.target.style.display = 'none'; }}
                          />
                        </td>
                        <td>
                          <div className="admin__movie-title">{movie.title}</div>
                          {movie.title_kz && <div className="admin__movie-subtitle">{movie.title_kz}</div>}
                        </td>
                        <td>
                          <span className={`badge badge-${movie.type}`}>
                            {movie.type === 'movie' ? 'Фильм' : movie.type === 'series' ? 'Сериал' : 'Мульт'}
                          </span>
                        </td>
                        <td>{movie.release_year}</td>
                        <td>
                          <span className="admin__rating">⭐ {Number(movie.rating).toFixed(1)}</span>
                        </td>
                        <td>
                          {movie.trailer_url ? (
                            <a href={movie.trailer_url} target="_blank" rel="noopener noreferrer" className="admin__trailer-link">▶ YouTube</a>
                          ) : (
                            <span className="admin__no-trailer">—</span>
                          )}
                        </td>
                        <td>{movie.is_new ? '✅' : '—'}</td>
                        <td>
                          <div className="admin__actions">
                            <button className="admin__edit-btn" onClick={() => openEditMovie(movie)}>✏️</button>
                            <button className="admin__delete-btn" onClick={() => handleDeleteMovie(movie.id, movie.title)}>🗑️</button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* ── USERS ── */}
        {tab === 'users' && (
          <div className="admin__section">
            <h1 className="admin__title">Пайдаланушыларды басқару</h1>
            {loading ? (
              <div className="admin__loading">Жүктелуде...</div>
            ) : (
              <div className="admin__table-wrap">
                <table className="admin__table">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Аты</th>
                      <th>Email</th>
                      <th>Рөл</th>
                      <th>Тіркелген</th>
                      <th>Әрекет</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map(u => (
                      <tr key={u.id} className={u.is_admin ? 'admin__row--admin' : ''}>
                        <td>#{u.id}</td>
                        <td>
                          <div className="admin__user-info">
                            <div className={`admin__user-avatar ${u.is_admin ? 'admin__user-avatar--admin' : ''}`}>
                              {u.is_admin ? '★' : u.username?.[0]?.toUpperCase()}
                            </div>
                            <span>{u.username}</span>
                          </div>
                        </td>
                        <td>{u.email}</td>
                        <td>
                          <span className={`admin__role-badge ${u.is_admin ? 'admin__role-badge--admin' : ''}`}>
                            {u.is_admin ? '★ Админ' : 'Пайдаланушы'}
                          </span>
                        </td>
                        <td>{new Date(u.created_at).toLocaleDateString('ru-RU')}</td>
                        <td>
                          <div className="admin__actions">
                            <button
                              className={u.is_admin ? 'admin__demote-btn' : 'admin__promote-btn'}
                              onClick={() => handleToggleAdmin(u.id)}
                              title={u.is_admin ? 'Админ рөлін алу' : 'Админ ету'}
                            >
                              {u.is_admin ? '⬇ Алу' : '⬆ Админ'}
                            </button>
                            {u.id !== user.id && (
                              <button className="admin__delete-btn" onClick={() => handleDeleteUser(u.id, u.username)}>🗑️</button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* ── REVIEWS ── */}
        {tab === 'reviews' && (
          <div className="admin__section">
            <h1 className="admin__title">Пікірлерді басқару</h1>
            {loading ? (
              <div className="admin__loading">Жүктелуде...</div>
            ) : (
              <div className="admin__table-wrap">
                <table className="admin__table">
                  <thead>
                    <tr>
                      <th>Пайдаланушы</th>
                      <th>Фильм</th>
                      <th>Баға</th>
                      <th>Пікір</th>
                      <th>Күні</th>
                      <th>Жою</th>
                    </tr>
                  </thead>
                  <tbody>
                    {reviews.map(r => (
                      <tr key={r.id}>
                        <td><strong>{r.username}</strong></td>
                        <td>{r.movie_title}</td>
                        <td><span className="admin__rating">⭐ {r.rating}/10</span></td>
                        <td className="admin__review-text">{r.comment?.slice(0, 80)}{r.comment?.length > 80 ? '…' : ''}</td>
                        <td>{new Date(r.created_at).toLocaleDateString('ru-RU')}</td>
                        <td>
                          <button className="admin__delete-btn" onClick={() => handleDeleteReview(r.id)}>🗑️</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
};

export default AdminPanel;
