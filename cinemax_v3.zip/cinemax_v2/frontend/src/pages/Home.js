import React, { useState, useEffect } from 'react';
import HeroBanner from '../components/HeroBanner';
import MovieRow from '../components/MovieRow';
import api from '../services/api';
import './Home.css';

const Home = () => {
  const [featured, setFeatured] = useState([]);
  const [movies, setMovies] = useState([]);
  const [series, setSeries] = useState([]);
  const [cartoons, setCartoons] = useState([]);
  const [newMovies, setNewMovies] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAll = async () => {
      try {
        const [featRes, movRes, serRes, carRes, newRes] = await Promise.all([
          api.get('/movies/featured'),
          api.get('/movies?type=movie&limit=12'),
          api.get('/movies?type=series&limit=12'),
          api.get('/movies?type=cartoon&limit=12'),
          api.get('/movies/new'),
        ]);
        setFeatured(featRes.data);
        setMovies(movRes.data);
        setSeries(serRes.data);
        setCartoons(carRes.data);
        setNewMovies(newRes.data);
      } catch (err) {
        console.error('Home fetch error:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchAll();
  }, []);

  return (
    <div className="home">
      <HeroBanner movies={loading ? [] : featured} />

      <div className="home__content container">
        <MovieRow title="🎬 Жаңа Фильмдер / Новинки" movies={newMovies} loading={loading} />
        <MovieRow title="🎥 Фильмдер / Фильмы" movies={movies} loading={loading} />
        <MovieRow title="📺 Сериалдар / Сериалы" movies={series} loading={loading} />
        <MovieRow title="🎠 Мультфильмдер" movies={cartoons} loading={loading} />
      </div>
    </div>
  );
};

export default Home;
