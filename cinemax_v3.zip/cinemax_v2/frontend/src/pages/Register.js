import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import './Auth.css';

const Register = () => {
  const [form, setForm] = useState({ username: '', email: '', password: '', confirm: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.username || !form.email || !form.password || !form.confirm) {
      setError('Барлық өрістерді толтырыңыз / Заполните все поля');
      return;
    }
    if (form.password.length < 6) {
      setError('Пароль кем дегенде 6 символ / Пароль минимум 6 символов');
      return;
    }
    if (form.password !== form.confirm) {
      setError('Парольдер сәйкес келмейді / Пароли не совпадают');
      return;
    }
    setLoading(true);
    try {
      await register(form.username, form.email, form.password);
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.error || 'Тіркелу мүмкін болмады / Ошибка регистрации');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-page__bg">
        <img src="https://image.tmdb.org/t/p/original/s3TBrRGB1iav7gFOCNx3H31MoES.jpg" alt="bg" />
        <div className="auth-page__bg-overlay" />
      </div>

      <div className="auth-container">
        <Link to="/" className="auth-logo">CINE<span>MAX</span></Link>

        <div className="auth-card">
          <div className="auth-card__header">
            <h1>Тіркелу</h1>
            <p>Создать аккаунт</p>
          </div>

          {error && <div className="error-msg">{error}</div>}

          <form onSubmit={handleSubmit} className="auth-form">
            <div className="auth-field">
              <label>Пайдаланушы аты / Имя пользователя</label>
              <input
                type="text"
                name="username"
                placeholder="Cinephile2024"
                value={form.username}
                onChange={handleChange}
                autoComplete="username"
              />
            </div>

            <div className="auth-field">
              <label>Email</label>
              <input
                type="email"
                name="email"
                placeholder="your@email.com"
                value={form.email}
                onChange={handleChange}
                autoComplete="email"
              />
            </div>

            <div className="auth-field">
              <label>Пароль / Құпия сөз</label>
              <input
                type="password"
                name="password"
                placeholder="Кем дегенде 6 символ"
                value={form.password}
                onChange={handleChange}
                autoComplete="new-password"
              />
            </div>

            <div className="auth-field">
              <label>Парольді растау / Подтвердите пароль</label>
              <input
                type="password"
                name="confirm"
                placeholder="••••••••"
                value={form.confirm}
                onChange={handleChange}
                autoComplete="new-password"
              />
            </div>

            <button type="submit" className="auth-submit" disabled={loading}>
              {loading ? <span className="auth-spinner" /> : 'Тіркелу / Зарегистрироваться'}
            </button>
          </form>

          <div className="auth-card__footer">
            <p>Аккаунт бар ма? / Уже есть аккаунт?</p>
            <Link to="/login" className="auth-link">
              Кіру / Войти →
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;
