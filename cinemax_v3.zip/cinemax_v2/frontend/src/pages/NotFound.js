import React from 'react';
import { Link } from 'react-router-dom';
import './NotFound.css';

const NotFound = () => (
  <div className="notfound page-wrapper">
    <div className="notfound__content">
      <div className="notfound__code">404</div>
      <h1 className="notfound__title">Бет табылмады</h1>
      <p className="notfound__subtitle">Страница не найдена</p>
      <p className="notfound__text">
        Іздеген бетіңіз жоқ немесе жойылған.<br />
        Искомая страница не существует или была удалена.
      </p>
      <Link to="/" className="notfound__btn">
        ← Басты бетке / На главную
      </Link>
    </div>
  </div>
);

export default NotFound;
