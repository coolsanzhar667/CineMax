import React, { useState, useEffect } from 'react';
import MovieGrid from '../components/MovieGrid';
import api from '../services/api';
import './CatalogPage.css';

const NewMovies = () => {
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/movies/new')
      .then(res => setMovies(res.data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="catalog-page page-wrapper">
      <div className="container">
        <div className="catalog-page__header">
          <div className="catalog-page__title-wrap">
            <span className="catalog-page__emoji">🆕</span>
            <div>
              <p className="catalog-page__title-kz">Жаңалықтар</p>
              <h1 className="catalog-page__title">Новинки</h1>
            </div>
          </div>
          <div className="catalog-page__search-info">
            <span>{movies.length} жаңалық / новинок</span>
          </div>
        </div>

        <div style={{ height: 32 }} />
        <MovieGrid movies={movies} loading={loading} />
      </div>
    </div>
  );
};

export default NewMovies;
