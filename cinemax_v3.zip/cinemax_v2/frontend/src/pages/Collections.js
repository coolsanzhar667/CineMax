import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import MovieCard from '../components/MovieCard';
import api from '../services/api';
import './Collections.css';

const Collections = () => {
  const [collections, setCollections] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    api.get('/collections')
      .then(res => setCollections(res.data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="collections page-wrapper">
        <div className="container">
          <div className="collections__loading">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="collections__skeleton skeleton" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="collections page-wrapper">
      <div className="container">
        <div className="catalog-page__header">
          <div className="catalog-page__title-wrap">
            <span className="catalog-page__emoji">🎯</span>
            <div>
              <p className="catalog-page__title-kz">Топтамалар</p>
              <h1 className="catalog-page__title">Подборки</h1>
            </div>
          </div>
        </div>

        <div className="collections__list">
          {collections.map(col => (
            <div key={col.id} className="collection-section">
              <div className="collection-section__header">
                <div>
                  <h2 className="collection-section__title">{col.title}</h2>
                  {col.description && (
                    <p className="collection-section__desc">{col.description}</p>
                  )}
                </div>
                <span className="collection-section__count">
                  {col.movie_count} фильм
                </span>
              </div>

              <div className="collection-section__scroll">
                {Array.isArray(col.movies) && col.movies.map(movie => (
                  <MovieCard key={movie.id} movie={movie} />
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Collections;
