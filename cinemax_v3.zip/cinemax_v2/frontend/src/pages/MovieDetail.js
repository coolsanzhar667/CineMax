import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';
import './MovieDetail.css';

const typeLabels = { movie: 'Фильм', series: 'Сериал', cartoon: 'Мультфильм' };

// Convert any YouTube URL to embed ID
function getYouTubeId(url) {
  if (!url) return null;
  const regexps = [
    /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
    /youtu\.be\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
  ];
  for (const r of regexps) {
    const m = url.match(r);
    if (m) return m[1];
  }
  return null;
}

const MovieDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [movie, setMovie] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showTrailer, setShowTrailer] = useState(false);
  const [reviewForm, setReviewForm] = useState({ rating: 8, comment: '' });
  const [submitting, setSubmitting] = useState(false);
  const [reviewError, setReviewError] = useState('');
  const [reviewSuccess, setReviewSuccess] = useState('');
  const [imgError, setImgError] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [movieRes, reviewsRes] = await Promise.all([
          api.get('/movies/' + id),
          api.get('/reviews/movie/' + id)
        ]);
        setMovie(movieRes.data);
        setReviews(reviewsRes.data);
      } catch (err) {
        if (err.response?.status === 404) navigate('/404');
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [id, navigate]);

  const handleReviewSubmit = async (e) => {
    e.preventDefault();
    if (!reviewForm.comment.trim()) {
      setReviewError('Пікірді жазыңыз / Напишите отзыв');
      return;
    }
    setSubmitting(true);
    setReviewError('');
    setReviewSuccess('');
    try {
      await api.post('/reviews', { movie_id: id, ...reviewForm });
      setReviewSuccess('Пікір қосылды! / Отзыв добавлен!');
      setReviewForm({ rating: 8, comment: '' });
      const res = await api.get('/reviews/movie/' + id);
      setReviews(res.data);
    } catch (err) {
      setReviewError(err.response?.data?.error || 'Қате болды / Ошибка');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteReview = async (reviewId) => {
    try {
      await api.delete('/reviews/' + reviewId);
      setReviews(prev => prev.filter(r => r.id !== reviewId));
    } catch (err) { console.error(err); }
  };

  if (loading) {
    return (
      <div className="movie-detail page-wrapper">
        <div className="movie-detail__loading container">
          <div className="skeleton movie-detail__hero-skeleton" />
          <div className="movie-detail__info-skeleton">
            <div className="skeleton" style={{ height: 40, width: '50%', marginBottom: 16 }} />
            <div className="skeleton" style={{ height: 20, width: '30%', marginBottom: 24 }} />
            <div className="skeleton" style={{ height: 80, marginBottom: 16 }} />
          </div>
        </div>
      </div>
    );
  }

  if (!movie) return null;

  const genres = Array.isArray(movie.genres) ? movie.genres.map(g => g.name_ru || g.name) : [];
  const avgRating = reviews.length
    ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1)
    : movie.rating;

  const youtubeId = getYouTubeId(movie.trailer_url);

  return (
    <div className="movie-detail page-wrapper">
      {/* Hero backdrop */}
      <div className="movie-detail__backdrop">
        <img
          src={movie.backdrop_url || movie.poster_url}
          alt={movie.title}
          onError={e => { e.target.src = movie.poster_url; }}
        />
        <div className="movie-detail__backdrop-gradient" />
      </div>

      <div className="container movie-detail__main">
        {/* Poster + Info */}
        <div className="movie-detail__top">
          {/* Poster */}
          <div className="movie-detail__poster-wrap">
            {!imgError && movie.poster_url ? (
              <img src={movie.poster_url} alt={movie.title}
                className="movie-detail__poster" onError={() => setImgError(true)} />
            ) : (
              <div className="movie-detail__no-poster">🎬</div>
            )}
            {movie.is_new && <span className="badge badge-new movie-detail__new-badge">Жаңа</span>}
          </div>

          {/* Info */}
          <div className="movie-detail__info">
            <div className="movie-detail__type-badge">
              <span className={"badge badge-" + movie.type}>{typeLabels[movie.type]}</span>
            </div>

            <h1 className="movie-detail__title">{movie.title}</h1>
            {movie.title_kz && movie.title_kz !== movie.title && (
              <p className="movie-detail__title-kz">{movie.title_kz}</p>
            )}

            {/* Stats */}
            <div className="movie-detail__stats">
              <div className="movie-detail__stat movie-detail__stat--gold">
                <svg viewBox="0 0 24 24" fill="#f5c518" width="20" height="20">
                  <polygon points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26"/>
                </svg>
                <strong>{Number(avgRating).toFixed(1)}</strong>
                <small>/ 10</small>
              </div>
              {movie.release_year && (
                <div className="movie-detail__stat">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="16" height="16">
                    <rect x="3" y="4" width="18" height="18" rx="2"/>
                    <line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/>
                    <line x1="3" y1="10" x2="21" y2="10"/>
                  </svg>
                  {movie.release_year}
                </div>
              )}
              {movie.duration && (
                <div className="movie-detail__stat">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="16" height="16">
                    <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
                  </svg>
                  {movie.duration} мин
                </div>
              )}
              <div className="movie-detail__stat">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="16" height="16">
                  <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                  <circle cx="12" cy="12" r="3"/>
                </svg>
                {movie.views?.toLocaleString()} қарау
              </div>
            </div>

            {/* Genres */}
            {genres.length > 0 && (
              <div className="movie-detail__genres">
                <span className="movie-detail__label">Жанр:</span>
                <div className="movie-detail__genre-tags">
                  {genres.map(g => <span key={g} className="movie-detail__genre-tag">{g}</span>)}
                </div>
              </div>
            )}

            {/* Description */}
            <div className="movie-detail__description">
              <span className="movie-detail__label">Сюжет:</span>
              <p>{movie.description || 'Сипаттама жоқ / Описание отсутствует'}</p>
            </div>

            {/* Actions */}
            <div className="movie-detail__actions">
              {youtubeId ? (
                <button
                  className="movie-detail__btn movie-detail__btn--play"
                  onClick={() => setShowTrailer(true)}
                >
                  <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20">
                    <polygon points="5,3 19,12 5,21"/>
                  </svg>
                  Трейлер қарау / Смотреть трейлер
                </button>
              ) : (
                <button className="movie-detail__btn movie-detail__btn--play movie-detail__btn--disabled" disabled>
                  <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20">
                    <polygon points="5,3 19,12 5,21"/>
                  </svg>
                  Трейлер жоқ
                </button>
              )}
              <button className="movie-detail__btn movie-detail__btn--back" onClick={() => navigate(-1)}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="18" height="18">
                  <polyline points="15 18 9 12 15 6"/>
                </svg>
                Артқа / Назад
              </button>
            </div>
          </div>
        </div>

        {/* YouTube Trailer Modal */}
        {showTrailer && youtubeId && (
          <div className="trailer-modal" onClick={() => setShowTrailer(false)}>
            <div className="trailer-modal__content" onClick={e => e.stopPropagation()}>
              <button className="trailer-modal__close" onClick={() => setShowTrailer(false)}>✕</button>
              <div className="trailer-modal__video">
                <iframe
                  src={"https://www.youtube.com/embed/" + youtubeId + "?autoplay=1&rel=0"}
                  title={movie.title + " трейлер"}
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              </div>
              <div className="trailer-modal__title">{movie.title} — Трейлер</div>
            </div>
          </div>
        )}

        {/* Reviews */}
        <div className="movie-detail__reviews">
          <h2 className="section-title">
            💬 Пікірлер / Отзывы
            <span className="reviews-count">{reviews.length}</span>
          </h2>

          {user ? (
            <form className="review-form" onSubmit={handleReviewSubmit}>
              <div className="review-form__header">
                <div className="review-form__avatar">{user.username?.[0]?.toUpperCase()}</div>
                <strong>{user.username}</strong>
              </div>
              {reviewError && <div className="error-msg">{reviewError}</div>}
              {reviewSuccess && <div className="success-msg">{reviewSuccess}</div>}
              <div className="review-form__rating">
                <label>Баға / Оценка: <strong>{reviewForm.rating}/10</strong></label>
                <input type="range" min="1" max="10" value={reviewForm.rating}
                  onChange={e => setReviewForm(p => ({ ...p, rating: +e.target.value }))}
                  className="review-form__slider" />
                <div className="review-form__rating-labels"><span>1</span><span>5</span><span>10</span></div>
              </div>
              <textarea className="review-form__textarea"
                placeholder="Пікіріңізді жазыңыз... / Напишите ваш отзыв..."
                value={reviewForm.comment}
                onChange={e => setReviewForm(p => ({ ...p, comment: e.target.value }))}
                rows={4} />
              <button type="submit" className="review-form__submit" disabled={submitting}>
                {submitting ? 'Жіберілуде...' : 'Пікір қалдыру / Оставить отзыв'}
              </button>
            </form>
          ) : (
            <div className="review-login-prompt">
              <p>Пікір қалдыру үшін кіріңіз / Войдите чтобы оставить отзыв</p>
              <button onClick={() => navigate('/login')} className="review-login-btn">Кіру / Войти</button>
            </div>
          )}

          <div className="reviews-list">
            {reviews.length === 0 ? (
              <div className="reviews-empty">
                <p>Әлі пікір жоқ. Бірінші болыңыз!</p>
                <small>Нет отзывов. Будьте первым!</small>
              </div>
            ) : reviews.map(review => (
              <div key={review.id} className="review-item">
                <div className="review-item__header">
                  <div className="review-item__avatar">{review.username?.[0]?.toUpperCase()}</div>
                  <div className="review-item__user">
                    <strong>{review.username}</strong>
                    <small>{new Date(review.created_at).toLocaleDateString('ru-RU')}</small>
                  </div>
                  <div className="review-item__rating">
                    <svg viewBox="0 0 24 24" fill="#f5c518" width="14" height="14">
                      <polygon points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26"/>
                    </svg>
                    {review.rating}/10
                  </div>
                  {user?.id === review.user_id && (
                    <button className="review-item__delete" onClick={() => handleDeleteReview(review.id)}>✕</button>
                  )}
                </div>
                <p className="review-item__comment">{review.comment}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MovieDetail;
