import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import GenreFilter from '../components/GenreFilter';
import MovieGrid from '../components/MovieGrid';
import api from '../services/api';
import './CatalogPage.css';

const CatalogPage = ({ type, title, titleKz, emoji }) => {
  const [movies, setMovies] = useState([]);
  const [genres, setGenres] = useState([]);
  const [selectedGenre, setSelectedGenre] = useState(null);
  const [loading, setLoading] = useState(true);
  const [searchParams] = useSearchParams();
  const searchQuery = searchParams.get('search');

  useEffect(() => {
    api.get('/genres').then(res => setGenres(res.data)).catch(console.error);
  }, []);

  useEffect(() => {
    setLoading(true);
    let url = '/movies?';
    if (type) url += `type=${type}&`;
    if (selectedGenre) url += `genre=${selectedGenre}&`;
    if (searchQuery) url += `search=${encodeURIComponent(searchQuery)}&`;
    url += 'sort=rating&limit=40';

    api.get(url)
      .then(res => setMovies(res.data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [type, selectedGenre, searchQuery]);

  const handleGenreSelect = (genre) => {
    setSelectedGenre(genre);
  };

  return (
    <div className="catalog-page page-wrapper">
      <div className="container">
        {/* Page header */}
        <div className="catalog-page__header">
          <div className="catalog-page__title-wrap">
            <span className="catalog-page__emoji">{emoji}</span>
            <div>
              <p className="catalog-page__title-kz">{titleKz}</p>
              <h1 className="catalog-page__title">{title}</h1>
            </div>
          </div>
          {searchQuery && (
            <div className="catalog-page__search-info">
              <span>Іздеу / Поиск:</span>
              <strong>"{searchQuery}"</strong>
              <span className="catalog-page__count">
                {movies.length} нәтиже / результатов
              </span>
            </div>
          )}
        </div>

        {/* Genre filter */}
        {!searchQuery && (
          <GenreFilter
            genres={genres}
            selected={selectedGenre}
            onSelect={handleGenreSelect}
          />
        )}

        {/* Movie grid */}
        <MovieGrid movies={movies} loading={loading} />
      </div>
    </div>
  );
};

export default CatalogPage;
