import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';

import Navbar from './components/Navbar';
import Home from './pages/Home';
import CatalogPage from './pages/CatalogPage';
import NewMovies from './pages/NewMovies';
import Collections from './pages/Collections';
import MovieDetail from './pages/MovieDetail';
import Login from './pages/Login';
import Register from './pages/Register';
import NotFound from './pages/NotFound';
import AdminPanel from './pages/AdminPanel';

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/movies" element={<CatalogPage type="movie" title="Фильмы" titleKz="Фильмдер" emoji="🎥" />} />
          <Route path="/series" element={<CatalogPage type="series" title="Сериалы" titleKz="Сериалдар" emoji="📺" />} />
          <Route path="/cartoons" element={<CatalogPage type="cartoon" title="Мультфильмы" titleKz="Мультфильмдер" emoji="🎠" />} />
          <Route path="/new" element={<NewMovies />} />
          <Route path="/collections" element={<Collections />} />
          <Route path="/movie/:id" element={<MovieDetail />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/admin" element={<AdminPanel />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
