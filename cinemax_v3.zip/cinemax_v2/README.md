# 🎬 CineMax — Онлайн Кино Сервисі

> **Курстық жоба / Курсовой проект**
> Тема: Онлайн кино көру және пікір қалдыру сервисін әзірлеу
> Стек: React + Node.js + PostgreSQL (pgAdmin)

---

## 📁 Жоба құрылымы / Структура проекта

```
cinemax/
├── backend/                  # Node.js + Express сервері
│   ├── config/
│   │   ├── db.js             # PostgreSQL подключение
│   │   └── init.sql          # SQL схема + тестовые данные
│   ├── middleware/
│   │   └── auth.js           # JWT аутентификация
│   ├── routes/
│   │   ├── auth.js           # /api/auth — Логин, Регистрация
│   │   ├── movies.js         # /api/movies — Фильмдер
│   │   ├── reviews.js        # /api/reviews — Пікірлер
│   │   ├── genres.js         # /api/genres — Жанрлар
│   │   └── collections.js    # /api/collections — Топтамалар
│   ├── .env                  # Конфигурация (DB, JWT)
│   ├── server.js             # Главный файл сервера
│   └── package.json
│
└── frontend/                 # React приложение
    ├── public/
    │   └── index.html
    └── src/
        ├── components/
        │   ├── Navbar.js/.css         # Навигация
        │   ├── HeroBanner.js/.css     # Главный баннер
        │   ├── MovieCard.js/.css      # Карточка фильма
        │   ├── MovieRow.js/.css       # Горизонтальный ряд
        │   ├── MovieGrid.js/.css      # Сетка фильмов
        │   └── GenreFilter.js/.css    # Фильтр по жанрам
        ├── context/
        │   └── AuthContext.js         # Авторизация (useState)
        ├── pages/
        │   ├── Home.js/.css           # Главная страница
        │   ├── CatalogPage.js/.css    # Фильмы/Сериалы/Мультфильмы
        │   ├── NewMovies.js           # Жаңалықтар / Новинки
        │   ├── Collections.js/.css    # Топтамалар / Подборки
        │   ├── MovieDetail.js/.css    # Детальная страница фильма
        │   ├── Login.js               # Вход
        │   ├── Register.js            # Регистрация
        │   ├── Auth.css               # Общие стили авторизации
        │   └── NotFound.js/.css       # 404 страница
        ├── services/
        │   └── api.js                 # Axios + JWT интерцептор
        ├── App.js                     # Роутер
        ├── index.js                   # Точка входа
        └── index.css                  # Глобальные стили
```

---

## 🚀 Іске қосу / Запуск проекта

### 1️⃣ PostgreSQL — База данных (pgAdmin)

1. Откройте **pgAdmin**
2. Правой кнопкой на **Databases** → **Create** → **Database**
3. Имя: `cinemax_db` → Сохранить
4. Откройте `cinemax_db` → **Query Tool**
5. Откройте файл `backend/config/init.sql` и выполните его (F5)
   - Создаются таблицы: users, movies, genres, reviews, collections
   - Добавляются 15 фильмов с постерами, жанрами и коллекциями

### 2️⃣ Backend — Node.js сервері

```bash
cd cinemax/backend

# Установить зависимости
npm install

# Отредактировать .env — указать ваш пароль от PostgreSQL:
# DB_PASSWORD=ваш_пароль

# Запустить сервер
npm run dev   # с автоперезагрузкой (nodemon)
# или
npm start     # обычный запуск
```

Сервер запустится на: **http://localhost:5000**

### 3️⃣ Frontend — React приложение

```bash
cd cinemax/frontend

# Установить зависимости
npm install

# Запустить
npm start
```

Откроется в браузере: **http://localhost:3000**

---

## ⚙️ .env конфигурация

Файл: `backend/.env`

```env
DB_HOST=localhost
DB_PORT=5432
DB_NAME=cinemax_db
DB_USER=postgres
DB_PASSWORD=ВАШ_ПАРОЛЬ    ← изменить!

JWT_SECRET=cinemax_super_secret_jwt_key_2024
PORT=5000
```

---

## 🌐 API Эндпоинттер / Эндпоинты

| Метод | URL | Описание |
|-------|-----|---------|
| POST | `/api/auth/register` | Тіркелу / Регистрация |
| POST | `/api/auth/login` | Кіру / Вход |
| GET | `/api/auth/me` | Текущий пользователь |
| GET | `/api/movies` | Все фильмы (фильтры: type, genre, search, sort) |
| GET | `/api/movies/featured` | Рекомендуемые |
| GET | `/api/movies/new` | Новинки |
| GET | `/api/movies/:id` | Детали фильма |
| GET | `/api/genres` | Все жанры |
| GET | `/api/reviews/movie/:id` | Отзывы к фильму |
| POST | `/api/reviews` | Добавить отзыв (🔒 auth) |
| DELETE | `/api/reviews/:id` | Удалить свой отзыв (🔒 auth) |
| GET | `/api/collections` | Все подборки |

---

## 📄 Беттер / Страницы

| URL | Страница |
|-----|---------|
| `/` | Басты бет / Главная — Hero баннер + ряды фильмов |
| `/movies` | Фильмдер / Фильмы — Жанр фильтр + сетка |
| `/series` | Сериалдар / Сериалы — Жанр фильтр + сетка |
| `/cartoons` | Мультфильмдер — Жанр фильтр + сетка |
| `/new` | Жаңалықтар / Новинки |
| `/collections` | Топтамалар / Подборки |
| `/movie/:id` | Фильм детали + пікірлер |
| `/login` | Кіру / Войти |
| `/register` | Тіркелу / Регистрация |

---

## 🎨 Дизайн ерекшеліктері / Особенности дизайна

- **Netflix-style** темная тема (#141414 фон)
- **Bebas Neue** — display шрифт для заголовков
- **Montserrat** — body шрифт
- Акцентный цвет: **#E50914** (Netflix red)
- Анимации: fadeIn, shimmer skeleton, hover scale
- Адаптивный дизайн (mobile/tablet/desktop)
- Hero баннер с автослайдером каждые 6 секунд
- Постеры с реальными изображениями TMDB

---

## 🗄️ База данных

### Таблицы:
- **users** — пользователи (id, username, email, password hash)
- **movies** — фильмы (title, poster, type, rating, release_year, description)
- **genres** — жанры (action, drama, horror и др.)
- **movie_genres** — связь фильм ↔ жанр
- **reviews** — отзывы (user_id, movie_id, rating 1-10, comment)
- **collections** — подборки
- **collection_movies** — связь подборка ↔ фильм

### Тестовые данные (из init.sql):
- 15 фильмов: Inception, Dark Knight, Breaking Bad, Stranger Things и др.
- 12 жанров на казахском и русском
- 4 коллекции
- Реальные постеры через TMDB CDN

---

## 🔐 Аутентификация

- **bcryptjs** — хеширование паролей
- **JWT** (7 дней) — хранится в localStorage
- Axios интерцептор — автоматически добавляет токен
- Защищённые маршруты для отзывов

---

## 🛠 Зависимости / Зависимости

### Backend:
```
express, cors, dotenv, pg, bcryptjs, jsonwebtoken, nodemon
```

### Frontend:
```
react, react-dom, react-router-dom, axios, react-scripts
```
